export enum UserType {
    SuperAdmin = "SuperAdmin",
    Admin = 'Admin',
}