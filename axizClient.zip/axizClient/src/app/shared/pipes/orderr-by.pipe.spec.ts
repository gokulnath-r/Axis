import { OrderrByPipe } from './orderr-by.pipe';

describe('OrderrByPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderrByPipe();
    expect(pipe).toBeTruthy();
  });
});
