import { DashboardRoutingModule } from './dashbord-routing.module';
import { HomeComponent } from './component/home/home.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { SideNavigationComponent } from './component/side-navigation/side-navigation.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashbordComponent } from './component/dashbord/dashbord.component';
import { CostCenterAccessComponent } from './component/cost-center-access/cost-center-access.component';
import { UserComponent } from './component/user/user.component';
import { LocationComponent } from './component/location/location.component';
import { ChainComponent } from './component/chain/chain.component';
import { CompanyComponent } from './component/company/company.component';
import { UsersAdminComponent } from './component/users-admin/users-admin.component';
import { CompanyAccessComponent } from './component/company-access/company-access.component';
import { ConnectingPathComponent } from './component/connecting-path/connecting-path.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AddUserComponent } from './component/popups/add-user-popup/add-user.component';
import { AddChainPopupComponent } from './component/popups/add-chain-popup/add-chain-popup.component';
import { AddCompanyPopupComponent } from './component/popups/add-company-popup/add-company-popup.component';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    NgbModule,
    DashboardRoutingModule
  ],
  declarations: [
    HomeComponent,
    DashbordComponent,
    SideNavigationComponent,
    CostCenterAccessComponent,
    UserComponent,
    LocationComponent,
    ChainComponent,
    CompanyComponent,
    UsersAdminComponent,
    CompanyAccessComponent,
    ConnectingPathComponent,
    AddUserComponent,
    AddChainPopupComponent,
    AddCompanyPopupComponent
  ],
  exports: [DashboardRoutingModule],
})
export class DashbordModule { }
