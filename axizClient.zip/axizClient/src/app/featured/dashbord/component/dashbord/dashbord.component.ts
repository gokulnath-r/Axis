import { LoaderService } from './../../../../shared/services/loader.service';
import { AlertService } from './../../../../shared/services/alert.service';
import { Component, OnInit } from '@angular/core';
import { DashbordService } from '../../services/dashbord.service';

@Component({
  selector: 'app-dashbord',
  templateUrl: './dashbord.component.html',
  styleUrls: ['./dashbord.component.css']
})
export class DashbordComponent implements OnInit {
  dashboardData: any;

  constructor(
    private dashBordService: DashbordService,
    private loaderSvc: LoaderService,
    private alert: AlertService,
  ) { }

  ngOnInit() {
    this.loaderSvc.showLoader();
    this.dashBordService.getUserDashboard(null).subscribe(val => {
      this.loaderSvc.hideLoader();
      this.dashboardData = val;
    });
  }

}
