export const environment = {
  production: true,
  baseUrl: 'http://iroidtechnologies.in/axis_laravel/api/',
  imageBase: 'http://realartdubai.com'
};
