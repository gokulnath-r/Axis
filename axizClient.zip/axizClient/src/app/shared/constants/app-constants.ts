export class AppConstants {
    // login
    public static LOGIN = 'url';
    public static LOGOUT = 'url';
}
