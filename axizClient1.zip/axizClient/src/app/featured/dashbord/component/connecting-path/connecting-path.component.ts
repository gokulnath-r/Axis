import { Component } from '@angular/core';

@Component({
    selector: 'connecting-path',
    templateUrl: 'connecting-path.component.html',
    styleUrls: ['connecting-path.component.scss']
})
export class ConnectingPathComponent {

}
